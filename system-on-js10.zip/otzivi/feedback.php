<?php
$zhaloba = $_POST['zhaloba'];
$acc = $_POST['account'];
file_put_contents('zhalobi.html', $acc.': '.$zhaloba.'<br><br>'."\n", FILE_APPEND);
echo '
<body id="body"
<div align="center">
<h1>Спасибо что поделились своим мнением.</h1>
<button onclick="location.href = \'index.html\'">Назад</button>
</div>
</body>
<script>
let darkTheme = window.matchMedia("(prefers-color-scheme: dark)");
if (darkTheme.matches) {
document.getElementById("body").style = \'background: #252525; color: white;\';
}
</script>';
?>
