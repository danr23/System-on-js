
setInterval(function() {
if (document.getElementById("bg_type").value == "col") {
var backg = document.getElementById("background").value;
let bg = `background: -moz-radial-gradient(circle farthest-corner at top, ${backg}, ${backg}, #202020) fixed;
background: -webkit-radial-gradient(circle farthest-corner at top, ${backg}, ${backg}, #000000) fixed;
background: -o-radial-gradient(circle farthest-corner at top, ${backg}, ${backg}, #000000) fixed;
background: radial-gradient(circle farthest-corner at top, ${backg}, ${backg}, #000000) fixed;`;
document.body.style = bg;
} else {
var bg = document.getElementById("bg_photo").value;
let stylebg = `background-image: url("./img/bgs/${bg}");
background-color: rgba(0,0,0,0);
background-repeat: no-repeat;
background-position: center;
background-size: cover;`;
document.body.style = stylebg;
}
}, 5);
