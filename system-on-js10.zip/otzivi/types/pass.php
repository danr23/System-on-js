<html>
<head>
<meta charset="utf-8">
</head>
<body id="body">
<div align="center">
Введите пароль администратора: <br><br>
<input type="password" id="pass" placeholder="Пароль" style="border: 2px solid #303030;border-radius: 15px;text-align:center;"></input><br><br>
<button onclick='pass();'>OK</button>
</div>
</body>
<script>
let darkTheme = window.matchMedia("(prefers-color-scheme: dark)");
if (darkTheme.matches) {
document.getElementById("body").style = 'background: #252525; color: white;';
}
function pass() {
if (document.getElementById("pass").value == "98gd") {
location.href = 'up.php';
}
}
</script>
</html>
