
var calc = document.getElementById('calc_window');
var otzivi = document.getElementById('otzivi_window');
var settings = document.getElementById('settings_window');
var browser = document.getElementById('browser_window');
var addr = document.getElementById('addr_window');
calc.onmousedown = function() { // 1. отследить нажатие
document.getElementById("title_calc").onmousedown = function(e) {
  // подготовить к перемещению
  // 2. разместить на том же месте, но в абсолютных координатах
calc.style.position = 'absolute';
  // переместим в body, чтобы мяч был точно не внутри position:relative
  document.body.appendChild(calc);

  calc.style.zIndex = 1000; // показывать мяч над другими элементами

  // передвинуть мяч под координаты курсора
  // и сдвинуть на половину ширины/высоты для центрирования
  function moveAt(e) {
    calc.style.top = e.pageY - calc.offsetHeight / 2 + 'px';
    calc.style.left = e.pageX - calc.offsetWidth / 2 + 'px';
  }

  // 3, перемещать по экрану
  document.onmousemove = function(e) {
    moveAt(e);
  }

  // 4. отследить окончание переноса
  calc.onmouseup = function() {
    document.onmousemove = null;
    calc.onmouseup = null;
  }
  calc.ondragstart = function() {
  return false;
};
}
}

settings.onmousedown = function() { // 1. отследить нажатие
document.getElementById("title_settings").onmousedown = function(e) {
  // подготовить к перемещению
  // 2. разместить на том же месте, но в абсолютных координатах
settings.style.position = 'absolute';
  // переместим в body, чтобы мяч был точно не внутри position:relative
  document.body.appendChild(settings);

  settings.style.zIndex = 1000; // показывать мяч над другими элементами

  // передвинуть мяч под координаты курсора
  // и сдвинуть на половину ширины/высоты для центрирования
  function moveAt(e) {
    settings.style.top = e.pageY - settings.offsetHeight / 2 + 'px';
    settings.style.left = e.pageX - settings.offsetWidth / 2 + 'px';
  }

  // 3, перемещать по экрану
  document.onmousemove = function(e) {
    moveAt(e);
  }

  // 4. отследить окончание переноса
  settings.onmouseup = function() {
    document.onmousemove = null;
    settings.onmouseup = null;
  }
    calc.ondragstart = function() {
  return false;
};
}
}
document.getElementById("calc").onclick = function() {
document.getElementById('calc_window').style.display = 'flex';
}
document.getElementById("close_calc").onclick = function() {
document.getElementById('calc_window').style.display = 'none';
document.getElementById("calc_content").style.width = '25%';
document.getElementById("calc_content").style.height = '45%';
document.getElementById('first-number').value = '';
document.getElementById('second-number').value = '';
document.getElementById('operation').innerHTML = '';
document.getElementById('answer').innerHTML = '';
}
document.getElementById("hidden_calc").onclick = function() {
document.getElementById('calc_window').style.display = 'none';
}
document.getElementById("restore_down").onclick = function() {
document.getElementById("calc_content").style.width = '75%';
document.getElementById("calc_content").style.height = '50%';
}
setInterval(function() {
if (document.getElementById("calc_content").style.width == '50%') {
document.getElementById("restore_down").onclick = function() {
document.getElementById("calc_content").style.width = '25%';
}
}else if (document.getElementById("calc_content").style.width == '25%') {
document.getElementById("restore_down").onclick = function() {
document.getElementById("calc_content").style.width = '50%';
}
}
}, 1);
document.getElementsByClassName("plus")[0].onclick = function() {
document.getElementById('answer').innerHTML = Number(document.getElementById('first-number').value)+Number(document.getElementById('second-number').value);
document.getElementById('operation').innerHTML = '+';
}
document.getElementsByClassName("minus")[0].onclick = function() {
document.getElementById('answer').innerHTML = Number(document.getElementById('first-number').value)-Number(document.getElementById('second-number').value);
document.getElementById('operation').innerHTML = '-';
}
document.getElementsByClassName("times")[0].onclick = function() {
document.getElementById('answer').innerHTML = Number(document.getElementById('first-number').value)*Number(document.getElementById('second-number').value);
document.getElementById('operation').innerHTML = '&times;';
}
document.getElementsByClassName("divide")[0].onclick = function() {
document.getElementById('answer').innerHTML = Number(document.getElementById('first-number').value)/Number(document.getElementById('second-number').value);
document.getElementById('operation').innerHTML = '&divide;';
}
document.getElementById("otzivi").onclick = function() {
document.getElementById('otzivi_window').style.display = 'flex';
}
document.getElementById("close_otzivi").onclick = function() {
document.getElementById('otzivi_window').style.display = 'none';
document.getElementById("otzivi_content").style.width = '25%';
document.getElementById("otzivi_content").style.height = '45%';
}
document.getElementById("hidden_otzivi").onclick = function() {
document.getElementById('otzivi_window').style.display = 'none';
}
document.getElementById("otzivi_restore_down").onclick = function() {
document.getElementById("otzivi_content").style.width = '75%';
document.getElementById("otzivi_content").style.height = '50%';
}
setInterval(function() {
if (document.getElementById("otzivi_content").style.width == '50%') {
document.getElementById("otzivi_restore_down").onclick = function() {
document.getElementById("otzivi_content").style.width = '25%';
}
}else if (document.getElementById("otzivi_content").style.width == '25%') {
document.getElementById("otzivi_restore_down").onclick = function() {
document.getElementById("otzivi_content").style.width = '50%';
}
}
}, 1);

document.getElementById("settings").onclick = function() {
document.getElementById('settings_window').style.display = 'flex';
}
document.getElementById("close_settings").onclick = function() {
document.getElementById('settings_window').style.display = 'none';
document.getElementById("settings_content").style.width = '25%';
document.getElementById("settings_content").style.height = '45%';
}
document.getElementById("hidden_settings").onclick = function() {
document.getElementById('settings_window').style.display = 'none';
}
document.getElementById("settings_restore_down").onclick = function() {
document.getElementById("settings_content").style.width = '75%';
document.getElementById("settings_content").style.height = '50%';
}
setInterval(function() {
if (document.getElementById("settings_content").style.width == '50%') {
document.getElementById("settings_restore_down").onclick = function() {
document.getElementById("settings_content").style.width = '25%';
}
}else if (document.getElementById("otzivi_content").style.width == '25%') {
document.getElementById("settings_restore_down").onclick = function() {
document.getElementById("settings_content").style.width = '50%';
}
}
}, 1);

document.getElementById("browser").onclick = function() {
document.getElementById('browser_window').style.display = 'flex';
}
document.getElementById("close_browser").onclick = function() {
document.getElementById('browser_window').style.display = 'none';
document.getElementById("browser_content").style.width = '25%';
document.getElementById("browser_content").style.height = '45%';
document.getElementById("browser_ifr").contentWindow.location.href = 'https://google.com/search?igu=1';
}
document.getElementById("hidden_browser").onclick = function() {
document.getElementById('browser_window').style.display = 'none';
}
document.getElementById("browser_restore_down").onclick = function() {
document.getElementById("browser_content").style.width = '75%';
document.getElementById("browser_content").style.height = '85%';
}
setInterval(function() {
if (document.getElementById("browser_content").style.width == '75%') {
document.getElementById("browser_restore_down").onclick = function() {
document.getElementById("browser_content").style.width = '25%';
document.getElementById("browser_content").style.height = '45%';
}
}else if (document.getElementById("browser_content").style.width == '25%') {
document.getElementById("browser_restore_down").onclick = function() {
document.getElementById("browser_content").style.width = '75%';
document.getElementById("browser_content").style.height = '85%';
}
}
}, 1);

document.getElementById("addr").onclick = function() {
document.getElementById('addr_window').style.display = 'flex';
}
document.getElementById("close_addr").onclick = function() {
document.getElementById('addr_window').style.display = 'none';
document.getElementById("addr_content").style.width = '25%';
document.getElementById("addr_content").style.height = '45%';
document.getElementById("addr_ifr").contentWindow.location.href = 'defpage.htm';
document.getElementById("addr_").value = '';
}
document.getElementById("hidden_addr").onclick = function() {
document.getElementById('addr_window').style.display = 'none';
}
document.getElementById("addr_restore_down").onclick = function() {
document.getElementById("addr_content").style.width = '75%';
document.getElementById("addr_content").style.height = '85%';
}
setInterval(function() {
if (document.getElementById("addr_content").style.width == '75%') {
document.getElementById("addr_restore_down").onclick = function() {
document.getElementById("addr_content").style.width = '25%';
document.getElementById("addr_content").style.height = '45%';
}
}else if (document.getElementById("addr_content").style.width == '25%') {
document.getElementById("addr_restore_down").onclick = function() {
document.getElementById("addr_content").style.width = '75%';
document.getElementById("addr_content").style.height = '85%';
}
}
}, 1);
document.getElementById("enter_addr").onclick = function() {
if (document.getElementById("addr_window").style.display == 'flex') {
document.getElementById("addr_ifr").contentWindow.location.href = document.getElementById("addr_").value;
}
}
