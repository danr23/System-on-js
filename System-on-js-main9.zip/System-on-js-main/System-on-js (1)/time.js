Date.prototype.stdTimezoneOffset = function() {
var jan = new Date(this.getFullYear(), 11, 1);
var jul = new Date(this.getFullYear(), 6, 1);
}
Date.prototype.isDstObserved = function() {
return this.getTimezoneOffset() < this.stdTimezoneOffset();
}
function getNameMonth(month) {
nameMonth = 0;
if (month == 0) {
nameMonth = "January";
}else if (month == 1) {
nameMonth = "February";
}else if (month == 2) {
nameMonth = "March";
}else if (month == 3) {
nameMonth = "April";
}else if (month == 4) {
nameMonth = "May";
}else if (month == 5) {
nameMonth = "June";
}else if (month == 6) {
nameMonth = "July";
}else if (month == 7) {
nameMonth = "August";
}else if (month == 8) {
nameMonth = "September";
}else if (month == 9) {
nameMonth = "October";
}else if (month == 10) {
nameMonth = "November";
}else if (month == 11) {
nameMonth = "December";
}
return nameMonth;
}
function getMinutesNormalFormat(min) {
if (min == 0) {
return "00";
}else if (min == 1) {
return "01";
}else if (min == 2) {
return "02";
}else if (min == 3) {
return "03";
}else if (min == 4) {
return "04";
}else if (min == 5) {
return "05";
}else if (min == 6) {
return "06";
}else if (min == 7) {
return "07";
}else if (min == 8) {
return "08";
}else if (min == 9) {
return "09";
}else if (min > 9) {
return min;
}
}

setInterval(function() {
document.getElementsByClassName("date")[0].style.color = document.getElementById("datecolor").value;
time = document.getElementById("time").value;
UTCTime = Number(document.getElementById("UTCTime").value);
today = new Date();
todayMonth = new Date();
todayDay = new Date();
var offset;
if (today.getTimezoneOffset()/60 < 0) {
offset = (today.getTimezoneOffset()/60)*-1;
} else {
offset = (today.getTimezoneOffset()/60);
}
today.setHours((today.getHours()+offset)+UTCTime);
if (document.getElementById("kindOfTime").value == "s") {
var timeValue;

if (today.getHours() > 0 && today.getHours() <= 12) {
  timeValue= "" + today.getHours();
} else if (today.getHours() > 12) {
  timeValue= "" + (today.getHours() - 12);
} else if (today.getHours() == 0) {
  timeValue= "12";
}
timeValue += (today.getMinutes() < 10) ? ":0" + today.getMinutes() : ":" + today.getMinutes();
timeValue += (today.getHours() >= 12) ? " P.M." : " A.M.";
if (time == "mohmi") {
document.getElementsByClassName("date")[0].innerHTML = getNameMonth(todayMonth.getMonth())+" "+todayDay.getDate()+" "+timeValue;
} else if (time == "ymohmi") {
document.getElementsByClassName("date")[0].innerHTML = today.getFullYear()+" "+getNameMonth(todayMonth.getMonth())+" "+todayDay.getDate()+" "+timeValue;
} else if (time == "hmiymo") {
document.getElementsByClassName("date")[0].innerHTML = timeValue+" "+today.getFullYear()+" "+getNameMonth(todayMonth.getMonth())+" "+todayDay.getDate();
} else if (time == "hmiy") {
document.getElementsByClassName("date")[0].innerHTML = timeValue+" "+today.getFullYear()+" "+todayDay.getDate();
} else if (time == "def") {
document.getElementsByClassName("date")[0].innerHTML = today.getFullYear()+"."+(todayMonth.getMonth()+1)+"."+todayDay.getDate()+", "+timeValue;
}
} else {
if (time == "mohmi") {
document.getElementsByClassName("date")[0].innerHTML = getNameMonth(todayMonth.getMonth())+" "+todayDay.getDate()+" "+today.getHours()+":"+getMinutesNormalFormat(today.getMinutes());
} else if (time == "ymohmi") {
document.getElementsByClassName("date")[0].innerHTML = today.getFullYear()+" "+getNameMonth(todayMonth.getMonth())+" "+todayDay.getDate()+" "+today.getHours()+":"+getMinutesNormalFormat(today.getMinutes());
} else if (time == "hmiymo") {
document.getElementsByClassName("date")[0].innerHTML = today.getHours()+":"+getMinutesNormalFormat(today.getMinutes())+" "+today.getFullYear()+" "+getNameMonth(todayMonth.getMonth())+" "+todayDay.getDate();
} else if (time == "hmiy") {
document.getElementsByClassName("date")[0].innerHTML = today.getHours()+":"+getMinutesNormalFormat(today.getMinutes())+" "+today.getFullYear()+" "+todayDay.getDate();
} else if (time == "def") {
document.getElementsByClassName("date")[0].innerHTML = today.getFullYear()+"."+(todayMonth.getMonth()+1)+"."+todayDay.getDate()+", "+today.getHours()+":"+getMinutesNormalFormat(today.getMinutes());
}
}
}, 1);
