<?php
$otziv = $_POST['input'];
$account = $_POST['accountInp'];
if ($_POST['rate'] == "5") {
$rate = ' <img src="stars/5s.png" width="61" height="18"></img>';
} elseif ($_POST['rate'] == "4") {
$rate = ' <img src="stars/4s.png" width="61" height="18"></img>';
} elseif ($_POST['rate'] == "3") {
$rate = ' <img src="stars/3s.png" width="61" height="18"></img>';
} elseif ($_POST['rate'] == "2") {
$rate = ' <img src="stars/2s.png" width="61" height="18"></img>';
} elseif ($_POST['rate'] == "1") {
$rate = ' <img src="stars/1s.png" width="61" height="18"></img>';
} else {
$rate = '';
}
file_put_contents('otzivi.html', $account.': '.$otziv.$rate."<br><br>"."\n", FILE_APPEND);
echo '
<script>
location.href = \'index.html\';
</script>
';
?>
