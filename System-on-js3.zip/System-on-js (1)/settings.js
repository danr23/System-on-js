
var backg = document.getElementById("background").innerHTML;
setInterval(function() {
var backg = document.getElementById("background").value;
let bg = `background: -moz-radial-gradient(circle farthest-corner at top, ${backg}, ${backg}, #202020) fixed;
background: -webkit-radial-gradient(circle farthest-corner at top, ${backg}, ${backg}, #000000) fixed;
background: -o-radial-gradient(circle farthest-corner at top, ${backg}, ${backg}, #000000) fixed;
background: radial-gradient(circle farthest-corner at top, ${backg}, ${backg}, #000000) fixed;`;
document.body.style = bg;
}, 5);
